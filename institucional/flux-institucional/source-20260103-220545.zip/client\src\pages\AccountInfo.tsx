import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/lib/supabase";
import { useLocation } from "wouter";

export default function AccountInfo() {
  const [, setLocation] = useLocation();
  const { isLoading, isAuthenticated, profile, supabaseUser, role } = useAuth();

  const [roleProfile, setRoleProfile] = useState<any | null>(null);
  const [roleProfileLoading, setRoleProfileLoading] = useState(false);

  useEffect(() => {
    let mounted = true;

    const run = async () => {
      // Se não está autenticado ou não tem role, seta loading false e retorna
      if (!isAuthenticated) {
        if (mounted) setRoleProfileLoading(false);
        return;
      }
      
      if (!role) {
        if (mounted) setRoleProfileLoading(false);
        return;
      }
      
      if (role !== "company" && role !== "driver") {
        if (mounted) setRoleProfileLoading(false);
        return;
      }
      
      setRoleProfileLoading(true);

      try {
        if (role === "company") {
          const { data } = await supabase
            .from("company_profiles")
            .select("company_name, state, city")
            .eq("user_id", supabaseUser?.id ?? "")
            .maybeSingle();
          if (mounted) setRoleProfile(data ?? null);
        }

        if (role === "driver") {
          const { data } = await supabase
            .from("driver_profiles")
            .select("vehicle_type, vehicle_model, plate, state, city")
            .eq("user_id", supabaseUser?.id ?? "")
            .maybeSingle();
          if (mounted) setRoleProfile(data ?? null);
        }
      } finally {
        if (mounted) setRoleProfileLoading(false);
      }
    };

    void run();
    return () => {
      mounted = false;
    };
  }, [isAuthenticated, role, supabaseUser?.id]);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setLocation("/login");
    }
  }, [isLoading, isAuthenticated, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6">
        Carregando...
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect via useEffect
  }

  return (
    <div className="min-h-screen bg-mesh-gradient">
      {/* Header with Logo */}
      <div className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-[oklch(0.88_0_0)]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <a href="/" className="flex items-center gap-2">
            <span className="font-brand text-2xl tracking-wider text-[oklch(0.15_0_0)]">
              FLUX
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-[oklch(0.45_0_0)]">Institucional</span>
          </a>
          <Button variant="ghost" onClick={() => setLocation("/")} className="text-sm font-semibold text-[oklch(0.45_0_0)] hover:text-[oklch(0.15_0_0)]">
            Voltar
          </Button>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-12">
        <Card className="w-full max-w-2xl mx-auto border-2 border-[oklch(0.88_0_0)] shadow-lg">
        <CardHeader className="bg-gradient-to-b from-[oklch(0.98_0_0)] to-white border-b border-[oklch(0.88_0_0)]">
          <CardTitle className="text-2xl text-[oklch(0.15_0_0)]">Informações da Conta</CardTitle>
          <CardDescription className="text-base text-[oklch(0.45_0_0)]">Dados básicos do usuário que fará a compra.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 pt-6">
          <div>
            <div className="text-sm text-muted-foreground">Nome</div>
            <div className="font-medium">{profile?.name ?? (supabaseUser?.user_metadata?.name as string | undefined) ?? "-"}</div>
          </div>

          <Separator />

          <div>
            <div className="text-sm text-muted-foreground">Email</div>
            <div className="font-medium">{profile?.email ?? supabaseUser?.email ?? "-"}</div>
          </div>

          <Separator />

          <div>
            <div className="text-sm text-muted-foreground">Tipo</div>
            <div className="font-medium">{role ?? "(não definido)"}</div>
          </div>

          <Separator />

          <div>
            <div className="text-sm text-muted-foreground">Cidade / Estado</div>
            <div className="font-medium">
              {roleProfileLoading ? "Carregando..." : `${roleProfile?.city ?? "-"} / ${roleProfile?.state ?? "-"}`}
            </div>
          </div>

          {role === "company" && (
            <>
              <Separator />
              <div>
                <div className="text-sm text-muted-foreground">Empresa</div>
                <div className="font-medium">{roleProfile?.company_name ?? "-"}</div>
              </div>
            </>
          )}

          {role === "driver" && (
            <>
              <Separator />
              <div>
                <div className="text-sm text-muted-foreground">Veículo</div>
                <div className="font-medium">
                  {roleProfile?.vehicle_type ? String(roleProfile.vehicle_type) : "-"}
                  {roleProfile?.vehicle_model ? ` • ${roleProfile.vehicle_model}` : ""}
                </div>
              </div>

              <Separator />
              <div>
                <div className="text-sm text-muted-foreground">Placa</div>
                <div className="font-medium">{roleProfile?.plate ?? "-"}</div>
              </div>
            </>
          )}

          <div className="pt-2 flex flex-col gap-3">
            <Button variant="outline" className="w-full font-bold text-base py-5" onClick={() => setLocation("/plano")}>Ver Plano Atual</Button>
            <Button className="w-full font-bold text-base py-5 bg-[oklch(0.15_0_0)] text-white hover:bg-[oklch(0.25_0_0)]" onClick={() => setLocation("/")}>Voltar ao site</Button>
          </div>
        </CardContent>
        </Card>
      </div>
    </div>
  );
}
