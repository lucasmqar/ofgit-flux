import { useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";

function formatDateBr(date: Date) {
  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

export default function CurrentPlan() {
  const [, setLocation] = useLocation();
  const { isLoading, isAuthenticated, credits, hasActiveCredits } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setLocation("/login");
    }
  }, [isLoading, isAuthenticated, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6">
        Carregando...
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6">
        <Card className="w-full max-w-xl">
          <CardHeader>
            <CardTitle>Você não está logado</CardTitle>
            <CardDescription>Entre para ver o status do seu plano.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full" onClick={() => setLocation("/login")}>Ir para Login</Button>
            <Button className="w-full" variant="outline" onClick={() => setLocation("/")}>Voltar</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        <Card className="w-full max-w-xl mx-auto">
        <CardHeader>
          <CardTitle>Plano Atual</CardTitle>
          <CardDescription>Status do seu acesso (créditos).</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">Status</div>
            {hasActiveCredits ? <Badge>Ativo</Badge> : <Badge variant="secondary">Inativo</Badge>}
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">Válido até</div>
            <div className="font-medium">
              {credits?.validUntil ? formatDateBr(credits.validUntil) : "-"}
            </div>
          </div>

          <div className="pt-2 flex flex-col gap-3">
            <Button className="w-full py-5" onClick={() => setLocation("/#planos")}>Ver Planos</Button>
            <Button variant="outline" className="w-full py-5" onClick={() => setLocation("/conta")}>Informações da Conta</Button>
            <Button variant="ghost" className="w-full py-5" onClick={() => setLocation("/")}>Voltar ao site</Button>
          </div>
        </CardContent>
        </Card>
      </div>
    </div>
  );
}
