// Test - Header Novo v2
export default function HeaderTest() {
  return <div>Header Test 2026-01-03-NOVO</div>;
}
