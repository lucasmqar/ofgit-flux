import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY ??
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY) as string | undefined;

const resolvedSupabaseUrl = supabaseUrl ?? "";
const resolvedSupabaseAnonKey = supabaseAnonKey ?? "";

if (!supabaseUrl || !supabaseAnonKey) {
  // Keep it as a runtime error to avoid silently breaking checkout.
  // Vite env vars are required for institutional checkout/login.
  // eslint-disable-next-line no-console
  console.warn(
    "[institucional] Missing VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY/VITE_SUPABASE_PUBLISHABLE_KEY",
  );
}

export const supabase = createClient(supabaseUrl ?? "", supabaseAnonKey ?? "", {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

// Re-export for callers that need to validate env.
export const SUPABASE_URL = resolvedSupabaseUrl;
export const SUPABASE_ANON_KEY = resolvedSupabaseAnonKey;

export async function getAccessToken(): Promise<string | null> {
  const { data } = await supabase.auth.getSession();
  return data.session?.access_token ?? null;
}

export async function signInWithGoogle() {
  // Keep auth inside the institutional site (no redirect to the app).
  // NOTE: Supabase Dashboard must allow this URL in Auth -> Redirect URLs.
  const redirectTo = `${window.location.origin}/?login=success#planos`;
  return supabase.auth.signInWithOAuth({
    provider: "google",
    options: { redirectTo },
  });
}

export async function signOut() {
  return supabase.auth.signOut();
}

export async function createStripeCheckout(planKey: string) {
  if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error("missing_supabase_env");
  }

  const token = await getAccessToken();
  if (!token) throw new Error("not_authenticated");

  const url = `${supabaseUrl}/functions/v1/create-stripe-checkout`;

  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: supabaseAnonKey,
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      planKey,
      // Keep user on the institutional site after Checkout.
      // The app can be opened manually from the profile menu.
      successUrl: "https://iflux.space/?checkout=success#planos",
      cancelUrl: "https://iflux.space/#planos",
    }),
  });

  const json = await res.json();
  if (!res.ok || !json?.success || !json?.url) {
    throw new Error(json?.error ?? "checkout_failed");
  }

  return json.url as string;
}
