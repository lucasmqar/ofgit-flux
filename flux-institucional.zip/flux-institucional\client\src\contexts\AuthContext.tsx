import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { Session, User as SupabaseUser } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabase";

export type AppRole = "admin" | "company" | "driver";

export type UserProfile = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
};

export type Credits = {
  userId: string;
  validUntil: Date;
};

export type VehicleType = "moto" | "car" | "bike";

export type SignUpPayload = {
  email: string;
  password: string;
  name: string;
  role: Exclude<AppRole, "admin">;
  phone?: string;
  state: string;
  city: string;
  companyName?: string;
  vehicleType?: VehicleType;
  vehicleModel?: string;
  plate?: string;
};

type AuthContextType = {
  session: Session | null;
  supabaseUser: SupabaseUser | null;
  profile: UserProfile | null;
  role: AppRole | null;
  credits: Credits | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  hasActiveCredits: boolean;

  signInWithGoogle: () => Promise<void>;
  signInWithPassword: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signUpWithPassword: (payload: SignUpPayload) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  setMyRole: (role: Exclude<AppRole, "admin">) => Promise<{ success: boolean; error?: string }>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

async function fetchProfile(userId: string) {
  const { data, error } = await supabase
    .from("profiles")
    .select("id, name, email, phone")
    .eq("id", userId)
    .maybeSingle();

  if (error) {
    // eslint-disable-next-line no-console
    console.error("[institucional] profile fetch failed", error);
    return null;
  }

  if (!data) return null;
  return {
    id: data.id as string,
    name: data.name as string,
    email: data.email as string,
    phone: (data.phone as string | null) ?? null,
  } satisfies UserProfile;
}

async function fetchRole(userId: string): Promise<AppRole | null> {
  const { data, error } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .maybeSingle();

  if (error) {
    // eslint-disable-next-line no-console
    console.error("[institucional] role fetch failed", error);
    return null;
  }

  return (data?.role as AppRole | undefined) ?? null;
}

async function fetchCredits(userId: string): Promise<Credits | null> {
  const { data, error } = await supabase
    .from("credits")
    .select("user_id, valid_until")
    .eq("user_id", userId)
    .maybeSingle();

  // No row is OK.
  if (error) {
    // eslint-disable-next-line no-console
    console.error("[institucional] credits fetch failed", error);
    return null;
  }

  if (!data) return null;

  return {
    userId: data.user_id as string,
    validUntil: new Date(data.valid_until as string),
  };
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [supabaseUser, setSupabaseUser] = useState<SupabaseUser | null>(null);

  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [credits, setCredits] = useState<Credits | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refreshUserData = useCallback(async (user: SupabaseUser) => {
    const [p, r, c] = await Promise.all([
      fetchProfile(user.id),
      fetchRole(user.id),
      fetchCredits(user.id),
    ]);

    setProfile(p);
    setRole(r);
    setCredits(c);
  }, []);

  useEffect(() => {
    let isMounted = true;

    // Listener FIRST
    const { data: authListener } = supabase.auth.onAuthStateChange(async (_event, nextSession) => {
      if (!isMounted) return;

      setSession(nextSession);
      setSupabaseUser(nextSession?.user ?? null);

      if (nextSession?.user) {
        await refreshUserData(nextSession.user);
      } else {
        setProfile(null);
        setRole(null);
        setCredits(null);
      }

      setIsLoading(false);
    });

    // THEN initial session
    supabase.auth
      .getSession()
      .then(async ({ data }) => {
        if (!isMounted) return;

        setSession(data.session);
        setSupabaseUser(data.session?.user ?? null);

        if (data.session?.user) {
          await refreshUserData(data.session.user);
        }

        setIsLoading(false);
      })
      .catch(() => {
        if (!isMounted) return;
        setIsLoading(false);
      });

    return () => {
      isMounted = false;
      authListener.subscription.unsubscribe();
    };
  }, [refreshUserData]);

  const signInWithGoogle = useCallback(async () => {
    const redirectTo = `${window.location.origin}/login`;
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo },
    });
    if (error) throw error;
  }, []);

  const signInWithPassword = useCallback(async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) return { success: false, error: error.message };
      return { success: true };
    } catch {
      return { success: false, error: "Erro ao fazer login" };
    }
  }, []);

  const signUpWithPassword = useCallback(async (payload: SignUpPayload) => {
    const {
      email,
      password,
      name,
      role: chosenRole,
      phone,
      state,
      city,
      companyName,
      vehicleType,
      vehicleModel,
      plate,
    } = payload;

    const trimmedState = state.trim();
    const trimmedCity = city.trim();

    if (!trimmedState || !trimmedCity) {
      return { success: false, error: "Informe estado e cidade." };
    }

    if (chosenRole === "company" && !companyName?.trim()) {
      return { success: false, error: "Informe o nome da empresa." };
    }

    if (chosenRole === "driver") {
      if (!vehicleType) return { success: false, error: "Selecione o tipo de veículo." };
      if (!vehicleModel?.trim()) return { success: false, error: "Informe o modelo do veículo." };
      if (!plate?.trim()) return { success: false, error: "Informe a placa." };
    }

      try {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}/login`,
            data: {
              name,
              phone: phone ?? null,
              role: chosenRole,
            },
          },
        });

        if (error) return { success: false, error: error.message };

        // If email confirmation is enabled, the session may not exist yet.
        const { data: sessionData } = await supabase.auth.getSession();
        const userId = sessionData.session?.user?.id;

        if (!userId) {
          return { success: true };
        }

        // Persist base profile (required by app).
        const profileRes = await supabase
          .from("profiles")
          .upsert(
            {
              id: userId,
              name,
              email,
              phone: phone ?? null,
            },
            { onConflict: "id" },
          );

        if (profileRes.error) {
          await supabase.auth.signOut();
          return { success: false, error: "Erro ao criar perfil: " + profileRes.error.message };
        }

        // Persist role-specific profile.
        if (chosenRole === "company") {
          const companyRes = await supabase
            .from("company_profiles")
            .upsert(
              {
                user_id: userId,
                company_name: companyName!.trim(),
                state: trimmedState,
                city: trimmedCity,
              },
              { onConflict: "user_id" },
            );

          if (companyRes.error) {
            await supabase.auth.signOut();
            return { success: false, error: "Erro ao criar perfil de empresa: " + companyRes.error.message };
          }
        }

        if (chosenRole === "driver") {
          const driverRes = await supabase
            .from("driver_profiles")
            .upsert(
              {
                user_id: userId,
                vehicle_type: vehicleType,
                vehicle_model: vehicleModel!.trim(),
                plate: plate!.trim(),
                state: trimmedState,
                city: trimmedCity,
              },
              { onConflict: "user_id" },
            );

          if (driverRes.error) {
            await supabase.auth.signOut();
            return { success: false, error: "Erro ao criar perfil de entregador: " + driverRes.error.message };
          }
        }

        return { success: true };
      } catch {
        return { success: false, error: "Erro ao criar conta" };
      }
  }, []);

  const setMyRole = useCallback(async (chosenRole: Exclude<AppRole, "admin">) => {
    try {
      const { data, error } = await supabase.rpc("set_my_role", { p_role: chosenRole });
      if (error) {
        if (error.message?.includes("role_already_set")) {
          return { success: false, error: "Sua conta já possui um tipo definido." };
        }
        return { success: false, error: error.message };
      }

      const newRole = (data as AppRole | null) ?? chosenRole;
      setRole(newRole);
      return { success: true };
    } catch {
      return { success: false, error: "Não foi possível definir seu tipo de conta." };
    }
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
  }, []);

  const isAuthenticated = !!session?.user;
  const hasActiveCredits = useMemo(() => {
    if (role === "admin") return true;
    if (!credits) return false;
    return credits.validUntil.getTime() > Date.now();
  }, [credits, role]);

  const value: AuthContextType = {
    session,
    supabaseUser,
    profile,
    role,
    credits,
    isLoading,
    isAuthenticated,
    hasActiveCredits,
    signInWithGoogle,
    signInWithPassword,
    signUpWithPassword,
    signOut,
    setMyRole,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
