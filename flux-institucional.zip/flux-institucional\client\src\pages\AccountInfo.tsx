import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/lib/supabase";
import { useLocation } from "wouter";

export default function AccountInfo() {
  const [, setLocation] = useLocation();
  const { isLoading, isAuthenticated, profile, supabaseUser, role } = useAuth();

  const [roleProfile, setRoleProfile] = useState<any | null>(null);
  const [roleProfileLoading, setRoleProfileLoading] = useState(false);

  useEffect(() => {
    let mounted = true;

    const run = async () => {
      if (!isAuthenticated || !role) return;
      if (role !== "company" && role !== "driver") return;
      setRoleProfileLoading(true);

      try {
        if (role === "company") {
          const { data } = await supabase
            .from("company_profiles")
            .select("company_name, state, city")
            .eq("user_id", supabaseUser?.id ?? "")
            .maybeSingle();
          if (mounted) setRoleProfile(data ?? null);
        }

        if (role === "driver") {
          const { data } = await supabase
            .from("driver_profiles")
            .select("vehicle_type, vehicle_model, plate, state, city")
            .eq("user_id", supabaseUser?.id ?? "")
            .maybeSingle();
          if (mounted) setRoleProfile(data ?? null);
        }
      } finally {
        if (mounted) setRoleProfileLoading(false);
      }
    };

    void run();
    return () => {
      mounted = false;
    };
  }, [isAuthenticated, role, supabaseUser?.id]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6">
        Carregando...
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-6">
        <Card className="w-full max-w-xl">
          <CardHeader>
            <CardTitle>Você não está logado</CardTitle>
            <CardDescription>Entre para ver suas informações.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full" onClick={() => setLocation("/login")}>Ir para Login</Button>
            <Button className="w-full" variant="outline" onClick={() => setLocation("/")}>Voltar</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-24 pb-12">
        <Card className="w-full max-w-xl mx-auto">
        <CardHeader>
          <CardTitle>Informações da Conta</CardTitle>
          <CardDescription>Dados básicos do usuário que fará a compra.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <div className="text-sm text-muted-foreground">Nome</div>
            <div className="font-medium">{profile?.name ?? (supabaseUser?.user_metadata?.name as string | undefined) ?? "-"}</div>
          </div>

          <Separator />

          <div>
            <div className="text-sm text-muted-foreground">Email</div>
            <div className="font-medium">{profile?.email ?? supabaseUser?.email ?? "-"}</div>
          </div>

          <Separator />

          <div>
            <div className="text-sm text-muted-foreground">Tipo</div>
            <div className="font-medium">{role ?? "(não definido)"}</div>
          </div>

          <Separator />

          <div>
            <div className="text-sm text-muted-foreground">Cidade / Estado</div>
            <div className="font-medium">
              {roleProfileLoading ? "Carregando..." : `${roleProfile?.city ?? "-"} / ${roleProfile?.state ?? "-"}`}
            </div>
          </div>

          {role === "company" && (
            <>
              <Separator />
              <div>
                <div className="text-sm text-muted-foreground">Empresa</div>
                <div className="font-medium">{roleProfile?.company_name ?? "-"}</div>
              </div>
            </>
          )}

          {role === "driver" && (
            <>
              <Separator />
              <div>
                <div className="text-sm text-muted-foreground">Veículo</div>
                <div className="font-medium">
                  {roleProfile?.vehicle_type ? String(roleProfile.vehicle_type) : "-"}
                  {roleProfile?.vehicle_model ? ` • ${roleProfile.vehicle_model}` : ""}
                </div>
              </div>

              <Separator />
              <div>
                <div className="text-sm text-muted-foreground">Placa</div>
                <div className="font-medium">{roleProfile?.plate ?? "-"}</div>
              </div>
            </>
          )}

          <div className="pt-2 flex flex-col md:flex-row gap-2">
            <Button variant="outline" className="w-full" onClick={() => setLocation("/plano")}>Ver Plano Atual</Button>
            <Button className="w-full" onClick={() => setLocation("/")}>Voltar ao site</Button>
          </div>
        </CardContent>
        </Card>
      </div>
    </div>
  );
}
