import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY ??
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY) as string | undefined;

const resolvedSupabaseUrl = supabaseUrl ?? "";
const resolvedSupabaseAnonKey = supabaseAnonKey ?? "";

if (!supabaseUrl || !supabaseAnonKey) {
  // Keep it as a runtime error to avoid silently breaking checkout.
  // Vite env vars are required for institutional checkout/login.
  // eslint-disable-next-line no-console
  console.warn(
    "[institucional] Missing VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY/VITE_SUPABASE_PUBLISHABLE_KEY",
  );
}

export const supabase = createClient(supabaseUrl ?? "", supabaseAnonKey ?? "", {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

// Re-export for callers that need to validate env.
export const SUPABASE_URL = resolvedSupabaseUrl;
export const SUPABASE_ANON_KEY = resolvedSupabaseAnonKey;

export async function getAccessToken(): Promise<string | null> {
  const { data } = await supabase.auth.getSession();
  return data.session?.access_token ?? null;
}

async function readResponsePayload(res: Response): Promise<any> {
  try {
    return await res.json();
  } catch {
    try {
      const text = await res.text();
      return text ? { message: text } : null;
    } catch {
      return null;
    }
  }
}

export async function signInWithGoogle() {
  // Keep auth inside the institutional site (no redirect to the app).
  // NOTE: Supabase Dashboard must allow this URL in Auth -> Redirect URLs.
  const redirectTo = `${window.location.origin}/?login=success#planos`;
  return supabase.auth.signInWithOAuth({
    provider: "google",
    options: { redirectTo },
  });
}

export async function signOut() {
  return supabase.auth.signOut();
}

export async function createStripeCheckout(planKey: string) {
  if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error("missing_supabase_env");
  }

  const tryRequest = async (token: string) => {
    const url = `${supabaseUrl}/functions/v1/create-stripe-checkout`;

    const controller = new AbortController();
    const timeoutMs = 20000;
    const timeoutId = window.setTimeout(() => controller.abort(), timeoutMs);

    try {
      return await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: supabaseAnonKey,
          Authorization: `Bearer ${token}`,
        },
        signal: controller.signal,
        body: JSON.stringify({
          planKey,
          // Keep user on the SAME origin after Checkout.
          // This prevents issues between iflux.space vs www.iflux.space (sessions are per-host).
          // The app can be opened manually from the profile menu.
          successUrl: `${window.location.origin}/?checkout=success#planos`,
          cancelUrl: `${window.location.origin}/#planos`,
        }),
      });
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") {
        throw new Error("checkout_timeout");
      }
      throw e;
    } finally {
      window.clearTimeout(timeoutId);
    }
  };

  let token = await getAccessToken();
  if (!token) throw new Error("not_authenticated");

  let res = await tryRequest(token);

  // If the access token is expired/invalid, refresh once and retry.
  if (res.status === 401) {
    try {
      await supabase.auth.refreshSession();
      token = await getAccessToken();
      if (token) {
        res = await tryRequest(token);
      }
    } catch {
      // ignore and fall through to normal error handling
    }
  }

  const payload = await readResponsePayload(res);

  if (!res.ok) {
    const message =
      (payload && (payload.error || payload.message)) || `${res.status} ${res.statusText}`;
    throw new Error(String(message));
  }

  if (!payload?.success || !payload?.url) {
    throw new Error(String(payload?.error ?? "checkout_failed"));
  }

  return payload.url as string;
}
